package sdibu.SecondYear.JavaTest.LibraryAdmin.dao;

import java.util.Date;
import java.util.List;

import sdibu.SecondYear.JavaTest.LibraryAdmin.bean.bookHistory;

public class functionTest {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
        
        dbBookHistoryFuncion dbFunc = new dbBookHistoryFuncion();
        dbFunc.addBookHistory("�ߴ�", 111);
    }
}

